MY DAY ✨ Android project

The existing my-day.html is included at:
app/src/main/assets/index.html

Package: com.myday.app
App name: MY DAY ✨
This project is designed to wrap the HTML app in an Android WebView.

Important:
- The ZIP is the project source, not a finished APK.
- An Android build environment is needed to compile the APK.
- Google Fonts in the HTML may require internet access.
